﻿# -*- coding: utf-8 -*-
with open("build_workflow.py", "r", encoding="utf-8") as f:
    c = f.read()

# Step 1: Replace title and requestedLines
old1 = "let title = '\u2728 M\u00dc\u015eTER\u0130 TALEB\u0130 / B\u0130LD\u0130R\u0130M';\nlet requestedLines = ['\u2713 Stok', '\u2713 Net fiyat', '\u2713 Bug\u00fcn kargo'];"
new1 = "let title = '\U0001f4e1 YEN\u0130 TALEP';\nlet extraInfo = '';"
c = c.replace(old1, new1)

# Step 2: Replace caseType titles
replacements = {
    "'\U0001f697 ARA\u00c7 BAZLI PAR\u00c7A ARAMA'": "'\U0001f4e1 ARA\u00c7 BAZLI ARAMA'",
    "'requestedLines = ['\u2713 Do\u011fru parc\u00e7a tespiti', '\u2713 Ara\u00e7 uyumlulu\u011fu', '\u2713 Stok ve net fiyat', '\u2713 Bug\u00fcn kargo'];": "extraInfo = vehicleStrings.length ? `\U0001f697 ${vehicleStrings[0]}` : '';",
    "'\U0001f6e0 UYUMLULUK VE PAR\u00c7A KONTROL\u00dc'": "'\U0001f4e1 UYUMLULUK SORGUSU'",
    "'\U0001f504 MUAD\u0130L / \u00c7APRAZ REFERANS TALEB\u0130'": "'\U0001f4e1 MUAD\u0130L ARAMA'",
    "'\U0001f525 SATI\u015e G\u00d6REV\u0130'": "'\U0001f4e1 STOK/F\u0130YAT SORGUSU'",
    "'intent === 'return_complaint' ? '\u015e\u0130KAYET / \u0130ADE' : '\u26a0\u00ef M\u00dc\u015eTER\u0130 DESTEK G\u00d6REV\u0130''": "'intent === 'return_complaint' ? '\U0001f4e1 \u015e\u0130KAYET / \u0130ADE' : '\U0001f4e1 DESTEK TALEB\u0130''",
    "'\u00dcr\u00fcn KODU / B\u0130LG\u0130 TAMAMLAMA'": "'\U0001f4e1 EKS\u0130K B\u0130LG\u0130'",
    "'requestedLines = ['\u2713 Tam \u00fcr\u00fcn kodu', '\u2713 Ara\u00e7 marka/model', '\u00dcretim y\u0131l\u0131 ve motor'];": "extraInfo = '🤖 M\u00fc\u015fteriden bilgi istendi';",
    "'\U0001f50e \u00dcr\u00fcn UZMANI \u0130NCELEMES\u0130'": "'\U0001f4e1 UZMANA AKTARIM'",
    "'\u26a0\u00ef AI DO\u011eRULAMA GEREKL\u0130'": "'\U0001f4e1 UZMANA AKTARIM'",
}

for old, new in replacements.items():
    c = c.replace(old, new)

# Step 3: Replace adminMessage template
old_msg = "const adminMessage = `${title}\\n\u23f1\ufe0f SLA: 5 dk\\n\\n\U0001f464 ${ctx.senderName}\\n\U0001f4de ${ctx.senderNumber}\\n\\n\U0001f4e6 \u00dcr\u00fcn/Kod\\n${codeText}\\n\\n\U0001f697 Ara\u00e7\\n${vehicleText}\\n\\n\U0001f3af \u0130stenen\\n${requestedLines.join('\\n')}\\n\\n\U0001f468 Atanan\\n${ctx.assigneeName || 'Ismail \u00d6zkaracan'}\\n\\n\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\\n\\n\U0001f4ac M\u00fc\u015fteri\\n\\\"${originalText}\\\"\\n\\n\U0001f916 AI m\u00fc\u015fteriye g\u00f6nderdi\\n\\\"${reply}\\\"${handoffReason ? `\\n\\n\U0001f4cc Handoff Nedeni: ${handoffReason}` : ''}`;"

new_msg = "const adminMessage = `${title}\\n\U0001f464 ${ctx.senderName} \u00b7 ${ctx.senderNumber}${extraInfo ? `\\n${extraInfo}` : ''}\\n\\n\U0001f4ac M\u00fc\u015fteri\\n\\\"${originalText}\\\"\\n\\n\U0001f916 Yan\u0131t G\u00f6nderildi\\n\\\"${reply}\\\"${handoffReason ? `\\n\\n\u26a0\ufe0f ${handoffReason}` : ''}`;"

c = c.replace(old_msg, new_msg)

with open("build_workflow.py", "w", encoding="utf-8") as f:
    f.write(c)

print("All templates updated")
