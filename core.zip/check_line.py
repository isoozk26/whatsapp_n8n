# -*- coding: utf-8 -*-
with open("build_workflow.py", "rb") as f:
    data = f.read()

marker = b"const adminMessage = "
idx = data.find(marker)
# Print bytes from marker to end of line
end = data.find(b";", idx)
print(f"Full line hex ({end-idx} bytes):")
print(data[idx:end+1].hex(' '))
print()
print(f"Full line text:")
print(data[idx:end+1].decode('utf-8'))