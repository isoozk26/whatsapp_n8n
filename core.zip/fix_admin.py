# -*- coding: utf-8 -*-
with open("build_workflow.py", "rb") as f:
    data = f.read()

# Find the adminMessage line and replace it
# The old line starts with "const adminMessage = `"
# We need to find it and replace the whole thing

# Find "const adminMessage = " pattern
marker = b"const adminMessage = "
idx = data.find(marker)
if idx == -1:
    print("Marker not found!")
else:
    print(f"Found marker at offset {idx}")
    # Find the end of the line (semicolon)
    end_idx = data.find(b";", idx)
    if end_idx == -1:
        print("Semicolon not found!")
    else:
        print(f"Line ends at offset {end_idx}")
        # Build new line
        # Template: const adminMessage = `${title}\n${ctx.senderName} · ${ctx.senderNumber}${extraInfo ? `\n${extraInfo}` : ''}\n\nMüşteri\n"${originalText}"\n\nYanıt Gönderildi\n"${reply}"${handoffReason ? `\n\n${handoffReason}` : ''}`;
        
        # Backtick = 0x60, dollar = 0x24, openbrace = 0x7B
        BT = bytes([0x60])
        DL = bytes([0x24])
        OB = bytes([0x7B])
        CB = bytes([0x7D])
        
        new_line = b"const adminMessage = " + BT + DL + OB + b"title" + CB + b"\\n" + DL + OB + b"ctx.senderName" + CB + b" \\xc2\\xb7 " + DL + OB + b"ctx.senderNumber" + CB + DL + OB + b"extraInfo ? " + BT + b"\\n" + DL + OB + b"extraInfo" + CB + BT + b" : ''" + CB + b"\\n\\nM\\xc3\\xbc\\xc5\\x9fteri\\n\\\"" + DL + OB + b"originalText" + CB + b"\\\"\\n\\nYan\\xc4\\xb1t G\\xc3\\xb6nderildi\\n\\\"" + DL + OB + b"reply" + CB + b"\\\"" + DL + OB + b"handoffReason ? " + BT + b"\\n\\n" + DL + OB + b"handoffReason" + CB + BT + b" : ''" + CB + BT + b";"
        
        # Replace
        data = data[:idx] + new_line + data[end_idx+1:]
        
        with open("build_workflow.py", "wb") as f:
            f.write(data)
        
        print("adminMessage line replaced")