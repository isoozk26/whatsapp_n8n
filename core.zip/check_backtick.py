# -*- coding: utf-8 -*-
with open("build_workflow.py", "rb") as f:
    data = f.read()

# The backtick should be 0x60, not the string "\x60"
# Let's check what's actually in the file around the adminMessage
marker = b"const adminMessage = "
idx = data.find(marker)
print(f"Bytes around marker: {data[idx:idx+30].hex(' ')}")

# Check if backtick is there
if data[idx+21] == 0x60:
    print("Backtick found at expected position")
else:
    print(f"Expected 0x60, got 0x{data[idx+21]:02x}")