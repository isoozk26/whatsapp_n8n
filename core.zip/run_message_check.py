import psycopg2
import os

DB_URL = "postgresql://n8n_user:1436c998130f03b6c19c9a19b49d504c85fd6141a76a97909b973d3530fd0b6e@localhost:5432/n8n"

try:
    conn = psycopg2.connect(DB_URL)
    conn.autocommit = True
    cur = conn.cursor()
    
    print("=" * 60)
    print("WHATSAPP AI - SON MESAJ KONTROL RAPORU")
    print("=" * 60)
    
    # 1. Son Mesajlar (Son 30 Dakika)
    print("\n1. SON MESAJLAR (Son 30 Dakika)")
    print("-" * 40)
    cur.execute("""
        SELECT 
          sender_number,
          sender_name,
          payload->>'conversation' as message_text,
          received_at
        FROM whatsapp_ai.messages
        WHERE received_at > now() - interval '30 minutes'
        ORDER BY received_at DESC
        LIMIT 20;
    """)
    rows = cur.fetchall()
    if rows:
        for row in rows:
            print(f"Tel: {row[0]} | İsim: {row[1]} | Mesaj: {row[2][:50]}... | Zaman: {row[3]}")
    else:
        print("Son 30 dakikada mesaj bulunamadı.")
    
    # 2. Kuyruk Durumu
    print("\n2. KUYRUK DURUMU")
    print("-" * 40)
    
    # Batch durumu
    print("Batch Durumu:")
    cur.execute("SELECT status, count(*) FROM whatsapp_ai.batches GROUP BY status;")
    rows = cur.fetchall()
    for row in rows:
        print(f"  {row[0]}: {row[1]}")
    
    # Teslimat durumu
    print("\nTeslimat Durumu (Kanala Göre):")
    cur.execute("SELECT status, channel, count(*) FROM whatsapp_ai.deliveries GROUP BY status, channel;")
    rows = cur.fetchall()
    for row in rows:
        print(f"  {row[0]} ({row[1]}): {row[2]}")
    
    # Sıkışmış batch'ler
    print("\nSıkışmış Processing Batch'leri (5 dk'dan uzun):")
    cur.execute("""
        SELECT sender_number, sender_name, status, processing_started_at,
               jsonb_array_length(pending_messages) as pending_count,
               jsonb_array_length(processing_messages) as processing_count
        FROM whatsapp_ai.batches
        WHERE status='processing' 
        AND processing_started_at < clock_timestamp()-interval '5 minutes';
    """)
    rows = cur.fetchall()
    if rows:
        for row in rows:
            print(f"  Tel: {row[0]} | İsim: {row[1]} | Processing Başlangıç: {row[3]}")
    else:
        print("  Sıkışmış batch bulunamadı.")
    
    # Son system eventler
    print("\nSon System Eventler:")
    cur.execute("""
        SELECT event_type, details, created_at 
        FROM whatsapp_ai.system_events
        ORDER BY created_at DESC LIMIT 10;
    """)
    rows = cur.fetchall()
    if rows:
        for row in rows:
            print(f"  {row[0]}: {row[1][:60]}... | {row[2]}")
    else:
        print("  Son event bulunamadı.")
    
    # 3. Son Teslim Edilen Mesajlar
    print("\n3. SON TESLİM EDİLEN MESAJLAR (Son 30 Dakika)")
    print("-" * 40)
    cur.execute("""
        SELECT 
          channel,
          destination,
          status,
          payload->>'text' as msg_text,
          created_at,
          sent_at,
          latency_ms
        FROM whatsapp_ai.deliveries
        WHERE created_at > now() - interval '30 minutes'
        ORDER BY created_at DESC
        LIMIT 20;
    """)
    rows = cur.fetchall()
    if rows:
        for row in rows:
            print(f"Kanal: {row[0]} | Hedef: {row[1]} | Durum: {row[2]} | Mesaj: {row[3][:30]}... | Zaman: {row[4]}")
    else:
        print("Son 30 dakikada teslimat bulunamadı.")
    
    # 4. Sistem Sağlık Durumu
    print("\n4. SİSTEM SAĞLIK DURUMU")
    print("-" * 40)
    try:
        cur.execute("SELECT * FROM whatsapp_ai.get_health_status();")
        row = cur.fetchone()
        if row:
            print(f"Durum: {row[0]}")
            print(f"Detay: {row[1]}")
        else:
            print("Sağlık durumu bilgisi bulunamadı.")
    except Exception as e:
        print(f"Sağlık durumu sorgulanırken hata: {e}")
    
    # 5. Circuit Breaker Durumu
    print("\n5. CIRCUIT BREAKER DURUMU")
    print("-" * 40)
    cur.execute("""
        SELECT service, state, consecutive_failures, opened_until, last_error_code
        FROM whatsapp_ai.service_circuits;
    """)
    rows = cur.fetchall()
    if rows:
        for row in rows:
            print(f"Servis: {row[0]} | Durum: {row[1]} | Hata Sayısı: {row[2]} | Açılma: {row[3]} | Son Hata: {row[4]}")
    else:
        print("Circuit breaker bilgisi bulunamadı.")
    
    print("\n" + "=" * 60)
    print("RAPOR TAMAMLANDI")
    print("=" * 60)
    
    cur.close()
    conn.close()
    
except Exception as e:
    print(f"Veritabanı bağlantı hatası: {e}")
    print("Lütfen veritabanı bağlantısını kontrol edin.")