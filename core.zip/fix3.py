﻿# -*- coding: utf-8 -*-
with open("build_workflow.py", "rb") as f:
    data = f.read()

# Find and replace the title line
old_title = b"let title = '\xf0\x9f\x93\xa2 M\xc3\x9c\xc5\x9eTER\xc4\xb0 TALEB\xc4\xb0 / B\xc4\xb0LD\xc4\xb0R\xc4\xb0M';"
new_title = b"let title = '\xf0\x9f\x93\xa1 YEN\xc4\xb0 TALEP';"
data = data.replace(old_title, new_title)

# Replace requestedLines
old_req = b"let requestedLines = ['\xe2\x9c\x93 Stok', '\xe2\x9c\x93 Net fiyat', '\xe2\x9c\x93 Bug\xc3\xbcn kargo'];"
new_req = b"let extraInfo = '';"
data = data.replace(old_req, new_req)

with open("build_workflow.py", "wb") as f:
    f.write(data)

print("Done")
