# -*- coding: utf-8 -*-
with open("build_workflow.py", "rb") as f:
    data = f.read()

# Replace literal \xc2\xb7 with actual bytes c2 b7 (·)
data = data.replace(b"\\xc2\\xb7", b"\xc2\xb7")

# Replace literal \xc3\xbc with actual bytes c3 bc (ü)
data = data.replace(b"\\xc3\\xbc", b"\xc3\xbc")

# Replace literal \xc5\x9f with actual bytes c5 9f (ş)
data = data.replace(b"\\xc5\\x9f", b"\xc5\x9f")

# Replace literal \xc4\xb1 with actual bytes c4 b1 (ı)
data = data.replace(b"\\xc4\\xb1", b"\xc4\xb1")

# Replace literal \xc3\xb6 with actual bytes c3 b6 (ö)
data = data.replace(b"\\xc3\\xb6", b"\xc3\xb6")

# Replace literal \n with actual newline
data = data.replace(b"\\n", b"\n")

# Replace literal \" with actual "
data = data.replace(b'\\"', b'"')

with open("build_workflow.py", "wb") as f:
    f.write(data)

print("Fixed all escape sequences")