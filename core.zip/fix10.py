# -*- coding: utf-8 -*-
with open("build_workflow.py", "r", encoding="utf-8") as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    if "const adminMessage" in line and "title" in line:
        indent = len(line) - len(line.lstrip())
        spaces = " " * indent
        # Build template
        t = "const adminMessage = `"
        t += "${title}\\n"
        t += "${ctx.senderName}"
        t += " \xb7 "
        t += "${ctx.senderNumber}"
        t += "${extraInfo ? `\\n${extraInfo}` : ''}"
        t += "\\n\\nMüşteri\\n\\\"${originalText}\\\"\\n\\nYanıt Gönderildi\\n\\\"${reply}\\\""
        t += "${handoffReason ? `\\n\\n${handoffReason}` : ''}`;"
        lines[i] = spaces + t + "\n"
        print(f"Replaced adminMessage at line {i+1}")
        break

with open("build_workflow.py", "w", encoding="utf-8") as f:
    f.writelines(lines)

print("adminMessage template updated")