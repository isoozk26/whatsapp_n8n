﻿# -*- coding: utf-8 -*-
with open("build_workflow.py", "r", encoding="utf-8") as f:
    c = f.read()

# Replace caseType titles
c = c.replace("'ARAÇ BAZLI PARÇA ARAMA'", "'ARAÇ BAZLI ARAMA'")
c = c.replace("'UYUMLULUK VE PARÇA KONTROLÜ'", "'UYUMLULUK SORGUSU'")
c = c.replace("'MUADİL / ÇAPRAZ REFERANS TALEBİ'", "'MUADİL ARAMA'")
c = c.replace("'SATIŞ GÖREVİ'", "'STOK/FİYAT SORGUSU'")
c = c.replace("'MÜŞTERİ DESTEK GÖREVİ'", "'DESTEK TALEBİ'")
c = c.replace("'ÜRÜN KODU / BİLGİ TAMAMLAMA'", "'EKSİK BİLGİ'")
c = c.replace("'ÜRÜN UZMANI İNCELEMESİ'", "'UZMANA AKTARIM'")
c = c.replace("'AI DOĞRULAMA GEREKLİ'", "'UZMANA AKTARIM'")

# Replace requestedLines assignments
c = c.replace("requestedLines = ['✓ Doğru parça tespiti', '✓ Araç uyumluluğu', '✓ Stok ve net fiyat', '✓ Bugün kargo'];", "extraInfo = vehicleStrings.length ?  vehicles[0] : '';")
c = c.replace("requestedLines = ['✓ Araç/parça uyumluluğu', '✓ Stok ve net fiyat'];", "")
c = c.replace("requestedLines = ['✓ Üretici kataloğu doğrulaması', '✓ Muadil kod', '✓ Stok ve net fiyat'];", "")
c = c.replace("requestedLines = ['✓ Stok', '✓ Net fiyat', '✓ Uyumluluk', '✓ Bugün kargo'];", "")
c = c.replace("requestedLines = ['✓ Sipariş bilgisini kontrol et', '✓ Sorunu/yanlış ürünü doğrula', '✓ İade/değişim sürecini başlat', '✓ Müşteriyle iletişime geç'];", "")
c = c.replace("requestedLines = ['✓ Tam ürün kodu', '✓ Araç marka/model', '✓ Üretim yılı ve motor'];", "extraInfo = 'Müşteriden bilgi istendi';")

with open("build_workflow.py", "w", encoding="utf-8") as f:
    f.write(c)

print("Titles and requestedLines replaced")
