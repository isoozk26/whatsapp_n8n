﻿import urllib.request
import json

API_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI1MzNhYWE1Yi0yYzA2LTRmOTEtYjU2NC1iZDBkY2YzMzBkYjQiLCJpc3MiOiJuOG4iLCJhdWQiOiJwdWJsaWMtYXBpIiwianRpIjoiZWQ5YTM4ODctMDEwMC00YzU5LTlmM2YtMDdiYWYxNjBhMjVlIiwiaWF0IjoxNzg0ODE5NTYxLCJleHAiOjE3OTI1MzAwMDB9.lQ-R6HMs0ljappkBcPSW01CEi7-cWDZEWiCBIwUFY6U'
BASE = 'https://n8n.filtreoto.online/api/v1'
HEADERS = {'X-N8N-API-KEY': API_KEY, 'Accept': 'application/json'}

def api_get(url):
    req = urllib.request.Request(url, headers=HEADERS)
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return resp.status, json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        body = e.read().decode()
        try:
            body_json = json.loads(body)
        except:
            body_json = body
        return e.code, body_json
    except Exception as e:
        return None, str(e)

print("=" * 60)
print("N8N HEALTH CHECK")
print("=" * 60)
code, data = api_get('https://n8n.filtreoto.online/healthz')
print("Status Code:", code)
if isinstance(data, (dict, list)):
    print("Response:", json.dumps(data, indent=2))
else:
    print("Response:", data)
healthy = False
if code == 200:
    if isinstance(data, dict):
        healthy = data.get('status') == 'ok' or data.get('healthy') == True
    else:
        healthy = True
print("Healthy:", healthy)

print()
print("=" * 60)
print("WORKFLOW STATUS")
print("=" * 60)
code, data = api_get(BASE + '/workflows/TjWxSi2Es51mjw5Z')
print("Status Code:", code)
if code == 200 and isinstance(data, dict):
    wf = data.get('data', data)
    print("Name:", wf.get('name'))
    print("Active:", wf.get('active'))
    print("ID:", wf.get('id'))
    ver = wf.get('versionId', wf.get('version', 'N/A'))
    print("Version:", ver)
    print("UpdatedAt:", wf.get('updatedAt', 'N/A'))
else:
    if isinstance(data, (dict, list)):
        print("Response:", json.dumps(data, indent=2))
    else:
        print("Response:", data)

print()
print("=" * 60)
print("LAST 5 EXECUTIONS")
print("=" * 60)
code, data = api_get(BASE + '/executions?limit=5')
print("Status Code:", code)
if code == 200 and isinstance(data, dict):
    results = data.get('results', data.get('data', []))
    if isinstance(results, list):
        for i, ex in enumerate(results, 1):
            eid = ex.get('id')
            status = ex.get('status')
            finished = ex.get('finished')
            started = ex.get('startedAt', 'N/A')
            stopped = ex.get('stoppedAt', 'N/A')
            print("%d. ID: %s | Status: %s | Finished: %s | Started: %s | Stopped: %s" % (i, eid, status, finished, started, stopped))
        print("Total executions returned:", len(results))
    else:
        out = json.dumps(data, indent=2)[:500]
        print("Response structure:", out)
else:
    if isinstance(data, (dict, list)):
        print("Response:", json.dumps(data, indent=2))
    else:
        print("Response:", data)
